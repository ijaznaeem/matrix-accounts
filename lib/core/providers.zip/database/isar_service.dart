import 'package:flutter/foundation.dart';
import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';

import '../../data/models/account_models.dart';
import '../../data/models/company_model.dart';
import '../../data/models/inventory_models.dart';
import '../../data/models/invoice_stock_models.dart';
import '../../data/models/party_model.dart';
import '../../data/models/payment_models.dart';
import '../../data/models/transaction_model.dart';
import '../../data/models/user_model.dart';
import '../../data/models/sync_change_model.dart';

class IsarService {
  Isar? _isar;
  bool _isInitializing = false;

  Isar get isar {
    if (_isar == null) {
      throw Exception('Isar not initialized yet');
    }
    return _isar!;
  }

  Future<void> init() async {
    if (_isar != null || _isInitializing) {
      return; // Already initialized or in process
    }

    _isInitializing = true;
    try {
      final dir = await getApplicationDocumentsDirectory();

      _isar ??= await Isar.open(
        [
          CompanySchema,
          UserSchema,
          CompanyUserSchema,
          PartySchema,
          UnitOfMeasureSchema,
          ItemCategorySchema,
          ProductSchema,
          TransactionSchema,
          TransactionLineSchema,
          InvoiceSchema,
          StockLedgerSchema,
          PaymentAccountSchema,
          PaymentInSchema,
          PaymentInLineSchema,
          PaymentOutSchema,
          PaymentOutLineSchema,
          AccountSchema,
          AccountTransactionSchema,
          SyncChangeSchema,
        ],
        directory: dir.path,
        inspector: kDebugMode,
      );
    } catch (e) {
      print('Failed to initialize Isar: $e');
      rethrow;
    } finally {
      _isInitializing = false;
    }
  }

  Future<void> close() async {
    if (_isar != null) {
      await _isar!.close();
      _isar = null;
    }
  }
}
